package mx.edu.ittepic.tpdm_u2_practica3_15401044

import android.content.Intent
import android.database.sqlite.SQLiteException
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AlertDialog
import kotlinx.android.synthetic.main.activity_main2.*
import kotlinx.android.synthetic.main.activity_main4.*

class Main2Activity : AppCompatActivity() {

    var btnReg:Button?=null
    var btnCL: Button?=null
    var Ldesc: EditText?=null
    var Lfech: EditText?=null
    var ListasM : ListView?= null
    var ListasGen: ArrayList<String> = ArrayList()
    var basedatos = BaseDatos(this,"PRACTICA1",null,1)   //Conexion para SQLite

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        btnReg=findViewById(R.id.btnRegresar)
        btnCL=findViewById(R.id.btnCrearLista)
        Ldesc=findViewById(R.id.txtDescLista)
        Lfech=findViewById(R.id.txtFechLista)
        ListasM=findViewById(R.id.Listas)

      //  MostrarListas()


        btnCL?.setOnClickListener {
            insertarLista()
        }
        btnReg?.setOnClickListener {
            var principal = Intent(this,MainActivity::class.java)
            startActivity(principal)
        }
    }//OnCreate

    fun insertarLista() {
        try {
            var transacion = basedatos.writableDatabase
            var SQL ="INSERT INTO LISTA VALUES(null,'DESCRIPCION','FECHACREACION')"

            SQL = SQL.replace("DESCRIPCION",txtDescLista?.text.toString())
            SQL = SQL.replace("FECHACREACION",txtFechLista?.text.toString())

            transacion.execSQL(SQL)
            transacion.close()
            mensaje("EXITO", "SE CREO CORRECTAMENTE LA LISTA ")
            limpiarCampos()
        }catch (err: SQLiteException){
            mensaje("Error", "NO SE CREO LA LISTA ")
        }
    }// ilseanumis
    fun MostrarListas(){

        try {
            var transaccion = basedatos.writableDatabase
            var SQL="SELECT * FROM LISTA"

            var  respuesta = transaccion.rawQuery(SQL,null)
            if (respuesta.moveToFirst()==true){
                do{
                    ListasGen?.add(respuesta.getString(0)+" | "+respuesta.getString(1)+" | "+respuesta.getString(2))

                }while(respuesta.moveToNext())
            }
            respuesta.close()
            val adapter = ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,ListasGen)
            ListasM?.setAdapter(adapter);

        }catch (err: SQLiteException){
       //     mensaje("ERROR","Hubo un error")
        }
    }


//--------------------------------------------------------------------------------------------------------
    fun mensaje(t: String, m: String) {
        AlertDialog.Builder(this).setTitle(t).setMessage(m)
                .setPositiveButton("OK") { dialog, which -> }.show()
        }//Funcion mensaje

    fun limpiarCampos() {
        Ldesc?.setText("")
        Lfech?.setText("")
    }//FuncionLimpiarCamposs


    }//Class